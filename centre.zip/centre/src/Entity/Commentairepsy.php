<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Commentairepsy
 *
 * @ORM\Table(name="commentairepsy", indexes={@ORM\Index(name="fk_pub_utilisateur2", columns={"id_utilisateur"}), @ORM\Index(name="id_publication2", columns={"id_publication2"})})
 * @ORM\Entity
 */
class Commentairepsy
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="date", type="datetime", nullable=false, options={"default"="current_timestamp()"})
     */
    private $date = 'current_timestamp()';

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="datem", type="datetime", nullable=false, options={"default"="current_timestamp()"})
     */
    private $datem = 'current_timestamp()';

    /**
     * @var string
     *
     * @ORM\Column(name="contenu", type="string", length=255, nullable=false)
     */
    private $contenu;

    /**
     * @var int|null
     *
     * @ORM\Column(name="id_utilisateur", type="integer", nullable=true, options={"default"="NULL"})
     */
    private $idUtilisateur = NULL;

    /**
     * @var \PublicationPsy
     *
     * @ORM\ManyToOne(targetEntity="PublicationPsy")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="id_publication2", referencedColumnName="id")
     * })
     */
    private $idPublication2;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getDate(): ?\DateTimeInterface
    {
        return $this->date;
    }

    public function setDate(\DateTimeInterface $date): self
    {
        $this->date = $date;

        return $this;
    }

    public function getDatem(): ?\DateTimeInterface
    {
        return $this->datem;
    }

    public function setDatem(\DateTimeInterface $datem): self
    {
        $this->datem = $datem;

        return $this;
    }

    public function getContenu(): ?string
    {
        return $this->contenu;
    }

    public function setContenu(string $contenu): self
    {
        $this->contenu = $contenu;

        return $this;
    }

    public function getIdUtilisateur(): ?int
    {
        return $this->idUtilisateur;
    }

    public function setIdUtilisateur(?int $idUtilisateur): self
    {
        $this->idUtilisateur = $idUtilisateur;

        return $this;
    }

    public function getIdPublication2(): ?PublicationPsy
    {
        return $this->idPublication2;
    }

    public function setIdPublication2(?PublicationPsy $idPublication2): self
    {
        $this->idPublication2 = $idPublication2;

        return $this;
    }


}
