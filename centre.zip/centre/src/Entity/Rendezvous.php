<?php

namespace App\Entity;
use App\Entity\Centre;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Rendezvous
 *
 * @ORM\Table(name="rendezvous", indexes={@ORM\Index(name="fk_centre", columns={"id_centre"}), @ORM\Index(name="fk_utilisateur", columns={"id_utilisateur"}), @ORM\Index(name="id_service", columns={"id_service"})})
 * @ORM\Entity(repositoryClass="App\Repository\RendezvousRepository")
 */
class Rendezvous
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var \DateTime|null
     *@Assert\GreaterThanOrEqual("today",message="Impossible ! veuillez choisir une date postérieure ou égale à aujoud'hui {{ compared_value }}")
     * @Assert\NotBlank (message="Specifier la date!")
     * @ORM\Column(name="date", type="date", nullable=true, options={"default"="NULL"})
     */
    private $date = null;

    /**
     * @var \DateTime|null
     * @Assert\NotBlank (message="Specifier le temps!")
     * @ORM\Column(name="temps", type="time", nullable=true, options={"default"="NULL"})
     */
    private $temps = null;

    /**
     * @var Centre
     *@Assert\NotBlank (message="Specifier le centre!")
     * @ORM\ManyToOne(targetEntity= Centre::class)
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="id_centre", referencedColumnName="id")
     * })
     */
    private $idCentre;

    /**
     * @var Utilisateur
     *
     * @ORM\ManyToOne(targetEntity="Utilisateur")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="id_utilisateur", referencedColumnName="id")
     * })
     */
    private $idUtilisateur;

    /**
     * @var Service
     *@Assert\NotBlank (message="Specifier le service!")
     * @ORM\ManyToOne(targetEntity=Service::class)
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="id_service", referencedColumnName="id")
     * })
     */
    private $idService;

    /**
     * Rendezvous constructor.
     */
    public function __construct()
    {
    }

    /**
     * @return int
     */



    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @param int $id
     */
    public function setId(int $id): void
    {
        $this->id = $id;
    }

    /**
     * @return \DateTime|null
     */
    public function getDate(): ?\DateTime
    {
        return $this->date;
    }

    /**
     * @param \DateTime|null $date
     */
    public function setDate(?\DateTime $date): void
    {
        $this->date = $date;
    }

    /**
     * @return \DateTime|null
     */
    public function getTemps(): ?\DateTime
    {
        return $this->temps;
    }

    /**
     * @param \DateTime|null $temps
     */
    public function setTemps(?\DateTime $temps): void
    {
        $this->temps = $temps;
    }

    /**
     * @return Centre|null
     */
    public function getIdCentre(): ?Centre
    {

        return $this->idCentre;
    }

    /**
     * @param Centre $idCentre
     */
    public function setIdCentre(Centre $idCentre): void
    {
        $this->idCentre = $idCentre;
    }

    /**
     * @return Utilisateur|null
     */
    public function getIdUtilisateur(): ?Utilisateur
    {
        return $this->idUtilisateur;
    }

    /**
     * @param Utilisateur $idUtilisateur
     */
    public function setIdUtilisateur(Utilisateur $idUtilisateur): void
    {
        $this->idUtilisateur = $idUtilisateur;
    }

    /**
     * @return Service|null
     */
    public function getIdService(): ?Service
    {
        return $this->idService;
    }

    /**
     * @param Service $idService
     */
    public function setIdService(Service $idService): void
    {
        $this->idService = $idService;
    }


}
