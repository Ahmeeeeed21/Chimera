<?php

namespace App\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\Validator\Context\ExecutionContextInterface;
use Symfony\Component\Serializer\Annotation\Groups;


/**
 * Centre
 *
 * @ORM\Table(name="centre")
 * @ORM\Entity(repositoryClass="App\Repository\CentreRepository")
 */
class Centre
{
    /**
     * @var int
     *@Groups("centres:read")
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string|null
     * @Groups("centres:read")
     *@Assert\NotBlank(message="Le nom ne doit pas etre vide!")
     * @ORM\Column(name="nom", type="string", length=70, nullable=true, options={"default"="NULL"})
     */
    private $nom = null;

    /**
     * @var string|null
     *@Assert\NotBlank(message="l'adresse ne doit pas etre vide!")
     * @Groups("centres:read")
     * @ORM\Column(name="lieu", type="string", length=120, nullable=true, options={"default"="NULL"})
     */
    private $lieu = null;

    /**
     * @var string|null
     * @Groups("centres:read")
     *@Assert\Length(min="5",minMessage= "La description doit contenir au moins {{ limit }} caractères!"))
     * @Assert\NotBlank(message="La description ne doit pas etre vide !")
     * @ORM\Column(name="Description", type="string", length=255, nullable=true, options={"default"="NULL"})
     */
    private $description = null;

    /**
     * @var string|null
     *@Groups("centres:read")
     * @ORM\Column(name="image", type="string", length=255, nullable=true, options={"default"="NULL"})
     */
    private $image = null;

    /**
     * @var string|null
     * @Groups("centres:read")
     *@Assert\NotBlank(message="Choisir le type du centre !")
     * @ORM\Column(name="type", type="string", length=100, nullable=true, options={"default"="NULL"})
     */
    private $type = null;

    /**
     * @var \DateTime|null
     *@Assert\NotBlank(message="Champs vide!")
     *@Groups("centres:read")
     * @ORM\Column(name="h_deb", type="time", nullable=true, options={"default"="NULL"})
     */
    private $hDeb = null;

    /**
     * @var \DateTime|null
     *@Assert\NotBlank(message="Champs vide!")
     *@Groups("centres:read")
     * @ORM\Column(name="h_fin", type="time", nullable=true, options={"default"="NULL"})
     */
    private $hFin = null;

    /**
     * @var \Doctrine\Common\Collections\Collection
     *@Groups("centres:read")
     * @ORM\ManyToMany(targetEntity="Service", inversedBy="idCentre")
     * @ORM\JoinTable(name="centre_service",
     *   joinColumns={
     *     @ORM\JoinColumn(name="id_centre", referencedColumnName="id")
     *   },
     *   inverseJoinColumns={
     *     @ORM\JoinColumn(name="id_service", referencedColumnName="id")
     *   }
     * )
     */
    private $idService;



    /**
     * Constructor
     */
    public function __construct()
    {
        $this->idService = new \Doctrine\Common\Collections\ArrayCollection();
    }

    public function __toString() {
        return $this->nom;
    }

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @param int $id
     */
    public function setId(int $id): void
    {
        $this->id = $id;
    }

    /**
     * @return string|null
     */
    public function getNom(): ?string
    {
        return $this->nom;
    }

    /**
     * @param string|null $nom
     */
    public function setNom(?string $nom): void
    {
        $this->nom = $nom;
    }

    /**
     * @return string|null
     */
    public function getLieu(): ?string
    {
        return $this->lieu;
    }

    /**
     * @param string|null $lieu
     */
    public function setLieu(?string $lieu): void
    {
        $this->lieu = $lieu;
    }

    /**
     * @return string|null
     */
    public function getDescription(): ?string
    {
        return $this->description;
    }

    /**
     * @param string|null $description
     */
    public function setDescription(?string $description): void
    {
        $this->description = $description;
    }

    /**
     * @return string|null
     */
    public function getImage(): ?string
    {
        return $this->image;
    }

    /**
     * @param string|null $image
     */
    public function setImage(?string $image): void
    {
        $this->image = $image;
    }

    /**
     * @return string|null
     */
    public function getType(): ?string
    {
        return $this->type;
    }

    /**
     * @param string|null $type
     */
    public function setType(?string $type): void
    {
        $this->type = $type;
    }

    /**
     * @return \DateTime|null
     */
    public function getHDeb()
    {
        return $this->hDeb;
    }

    /**
     * @param \DateTime|null $hDeb
     */
    public function setHDeb($hDeb): void
    {
        $this->hDeb = $hDeb;
    }

    /**
     * @return \DateTime|null
     */
    public function getHFin()
    {
        return $this->hFin;
    }

    /**
     * @param \DateTime|null $hFin
     */
    public function setHFin($hFin): void
    {
        $this->hFin = $hFin;
    }

    /**
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getIdService()
    {
        return $this->idService;
    }

    /**
     * @param \Doctrine\Common\Collections\Collection $idService
     */
    public function setIdService($idService): void
    {
        $this->idService = $idService;
    }


    public function addIdService(Service $c)
    {
        $this->idService[]=$c;
    }

    public function removeIdService(Service $idService): self
    {
        $this->idService->removeElement($idService);

        return $this;
    }



}
