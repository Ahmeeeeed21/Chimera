<?php

namespace App\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Service
 *
 * @ORM\Table(name="service")
 * @ORM\Entity(repositoryClass="App\Repository\ServiceRepository")
 */
class Service
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string|null
     *@Assert\NotBlank(message="Le nom ne doit pas etre vide!")
     * @ORM\Column(name="nom", type="string", length=70, nullable=true, options={"default"="NULL"})
     */
    private $nom = null;

    /**
     * @var string|null
     *@Assert\Length(min="5",max="70",minMessage= "La description doit contenir au moins {{ limit }} caractères!",maxMessage= "La description doit contenir maximum {{ limit }} caractères!"))
     * @Assert\NotBlank(message="La description ne doit pas etre vide !")
     * @ORM\Column(name="Description", type="string", length=255, nullable=true, options={"default"="NULL"})
     */
    private $description = null;

    /**
     * @var string|null
     *
     * @ORM\Column(name="type", type="string", length=50, nullable=true, options={"default"="NULL"})
     */
    private $type = null;

    /**
     * @var \Doctrine\Common\Collections\Collection
     *
     * @ORM\ManyToMany(targetEntity="Centre", mappedBy="idService")
     */
    private $idCentre;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->idCentre = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @param int $id
     */
    public function setId(int $id): void
    {
        $this->id = $id;
    }

    /**
     * @return string|null
     */
    public function getNom(): ?string
    {
        return $this->nom;
    }

    /**
     * @param string|null $nom
     */
    public function setNom(?string $nom): void
    {
        $this->nom = $nom;
    }

    /**
     * @return string|null
     */
    public function getDescription(): ?string
    {
        return $this->description;
    }

    /**
     * @param string|null $description
     */
    public function setDescription(?string $description): void
    {
        $this->description = $description;
    }

    /**
     * @return string|null
     */
    public function getType(): ?string
    {
        return $this->type;
    }

    /**
     * @param string|null $type
     */
    public function setType(?string $type): void
    {
        $this->type = $type;
    }

    /**
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getIdCentre()
    {
        return $this->idCentre;
    }

    /**
     * @param \Doctrine\Common\Collections\Collection $idCentre
     */
    public function setIdCentre($idCentre): void
    {
        $this->idCentre = $idCentre;
    }

    /**
     * @param Centre $c
     */
    public function addIdCentre(Centre $c)
    {
        $this->idCentre[]=$c;
    }

    public function removeIdCentre(Centre $idCentre): self
    {
        if ($this->idCentre->removeElement($idCentre)) {
            $idCentre->removeIdService($this);
        }

        return $this;
    }




}
