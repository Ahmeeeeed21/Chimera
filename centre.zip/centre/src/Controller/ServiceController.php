<?php

namespace App\Controller;


use App\Entity\Service;

use App\Form\ServiceType;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class ServiceController extends AbstractController
{
    /**
     * @Route("/service", name="service")
     */
    public function index(): Response
    {
        return $this->render('service/index.html.twig', [
            'controller_name' => 'ServiceController',
        ]);
    }

    /**
     * @return Response
     * @Route("/afficherService",name="affserv")
     */
    public function afficher()
    {
        $rep=$this->getDoctrine()->getRepository(Service::class);
        $services=$rep->findAll();
        return $this->render('service/affiche.html.twig'
            ,['services'=>$services]
        );
    }


    /**
     * @param $id
     * @return \Symfony\Component\HttpFoundation\RedirectResponse
     * @Route("/suppSer/{id}",name="supprimerserv")
     */
    public function supprimer($id)
    {
        $rep=$this->getDoctrine()->getRepository(Service::class);
        $em=$this->getDoctrine()->getManager();
        $c=$rep->find($id);
        $em->remove($c);
        $em->flush();
        return $this->redirectToRoute('affserv');

    }


    /**
     * @param Request $request
     * @return \Symfony\Component\HttpFoundation\RedirectResponse|Response
     * @Route("/ajouterService",name="ajouterserv")
     */
    public function ajouter(Request $request)
    {
        $service= new Service();
        $form=$this->createForm(ServiceType::class,$service);
        $form->add('Ajouter',SubmitType::class,['attr'=>['class'=>'btn btn-primary m-b-0']]);
        $form->handleRequest($request);

        if($form->isSubmitted() && $form->isValid())
        {
            $em=$this->getDoctrine()->getManager();
            $em->persist($service);
            $em->flush();
            return $this->redirectToRoute('affserv');
        }

        return $this->render('service/ajouter.html.twig',
            ['form'=>$form->createView()]
        );
    }


    /**
     * @param Request $request
     * @param $id
     * @return \Symfony\Component\HttpFoundation\RedirectResponse|Response
     * @Route("/modifierService/{id}",name="modifierserv")
     */
    public function modifier(Request $request,$id)
    {
        $rep=$this->getDoctrine()->getRepository(Service::class);
        $service= $rep->find($id);
        $form=$this->createForm(ServiceType::class,$service);
        $form->add('Modifier',SubmitType::class,['attr'=>['class'=>'btn btn-primary m-b-0']]);
        $form->handleRequest($request);

        if($form->isSubmitted() && $form->isValid())
        {
            $em=$this->getDoctrine()->getManager();
            $em->persist($service);
            $em->flush();
            return $this->redirectToRoute('affserv');
        }

        return $this->render('service/modifier.html.twig',
            ['form'=>$form->createView()]
        );
    }
}
