<?php

namespace App\Controller;

use App\Entity\Centre;
use App\Entity\Rendezvous;
use App\Entity\Service;
use App\Entity\Utilisateur;
use App\Repository\RendezvousRepository;
use Knp\Bundle\SnappyBundle\Snappy\Response\PdfResponse;
use Knp\Snappy\Pdf;
use Symfony\Bridge\Twig\Mime\NotificationEmail;
use Symfony\Component\Mailer\MailerInterface;
use Symfony\Component\Mime\Email;

use App\Form\RendezvousType;
use Dompdf\Dompdf;
use Dompdf\Options;

use DateTime;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;


class RendezvousController extends AbstractController
{


    /**
     * @return Response
     * @Route("/Rendezvous",name="grdv")
     */
    public function afficher()
    {
        $rep=$this->getDoctrine()->getRepository(Rendezvous::class);
        $idu=79;
        $rdvs=$rep->findBy(['idUtilisateur'=>$idu]);
        //$rdvs=$rep->findAll();
        $rdvss = [];

        foreach($rdvs as $event){
            $rdvss[] = [
                'id'=> $event->getId(),
                'date' => $event->getDate()->format('Y-m-d'),
                'time'=> $event->getTemps()->format('H:i'),
                'title'=>$event->getIdCentre()->getNom(),

            ];

        }



        return $this->render('rendezvous/afficher.html.twig', ['data'=>$rdvss]);
    }


    /**
     * @param Request $request

     * @return \Symfony\Component\HttpFoundation\RedirectResponse|Response
     * @Route("/ajouterrdv",name="ajouterrdv")
     */
    public function ajouter(Request $request)
    {
        $rdv= new Rendezvous();


        $form=$this->createForm(RendezvousType::class,$rdv);
        $form->add('Ajouter',SubmitType::class,['attr'=>['class'=>'btn btn-primary m-b-0']]);
        $form->handleRequest($request);

        if($form->isSubmitted() && $form->isValid())
        {   $repuser=$this->getDoctrine()->getRepository(Utilisateur::class);
            $idu=79;
            $user=$repuser->findOneBy(['id'=>$idu]);
            $rdv->setIdUtilisateur($user);
            $em=$this->getDoctrine()->getManager();
            $em->persist($rdv);
            $em->flush();
            return $this->redirectToRoute('grdv');
        }

        return $this->render('rendezvous/ajouter.html.twig',
            ['form'=>$form->createView()]
        );
    }


    /**
     * @param $id
     * @return \Symfony\Component\HttpFoundation\RedirectResponse
     * @Route("/supprimerrdv/{id}",name="supprdv")
     */
    public function supprimer($id)
    {
        $rep=$this->getDoctrine()->getRepository(Rendezvous::class);
        $em=$this->getDoctrine()->getManager();
        $c=$rep->find($id);
        $em->remove($c);
        $em->flush();
        return $this->redirectToRoute('grdv');

    }


    /**
     * @param $id
     * @param $date
     * @return \Symfony\Component\HttpFoundation\RedirectResponse
     * @Route("/moddate/{id}/{date}",name="modrdvf")
     */
    public function modifierDate($id,$date)
    {
        $d=DateTime::createFromFormat('Y-m-d', $date);
        $d->modify('+ 1 day');
        $rep=$this->getDoctrine()->getRepository(Rendezvous::class);
        $em=$this->getDoctrine()->getManager();
        $c=$rep->find($id);
        $c->setDate($d);
        $em->flush();
        return $this->redirectToRoute('grdv');
    }


    /**
     * @return Response
     * @Route("/afficherRdvB",name="afficherRdvB")
     */
    public function afficherBack()
    {
        $rep=$this->getDoctrine()->getRepository(Rendezvous::class);
        $rdvs=$rep->findAll();
        $rep3=$this->getDoctrine()->getRepository(Centre::class);
        $centres=$rep3->findAll();
        $rep2=$this->getDoctrine()->getRepository(Utilisateur::class);
        $users=$rep2->findAll();
        return $this->render('rendezvous/afficherb.html.twig'
            ,['rdvs'=>$rdvs,'centres'=>$centres,'users'=>$users]
        );
    }


    /**
     * @param $id
     * @Route("/telechargerrdv/{id}", name="pdfrdv")
     */
    public function telecharger($id,Pdf $knpSnappyPdf)
    {
        $rep=$this->getDoctrine()->getRepository(Rendezvous::class);
        $c=$rep->find($id);

        $html = $this->renderView('rendezvous/mypdf.html.twig', [
            'rdv' => $c
        ]);

        return new PdfResponse(
            $knpSnappyPdf->getOutputFromHtml($html),
            'file.pdf'
        );
        //pdf

        /*
        // Configure Dompdf according to your needs
        $pdfOptions = new Options();
        $pdfOptions->set('defaultFont', 'Arial');
       // $pdfOptions->set('isHtml5ParserEnabled', true);
       // $pdfOptions->set('isRemoteEnabled', true);

        // Instantiate Dompdf with our options
        $dompdf = new Dompdf($pdfOptions);
        // Retrieve the HTML generated in our twig file
        $html = $this->renderView('rendezvous/mypdf.html.twig', [
            'rdv' => $c
        ]);
       // $html .='<link rel="stylesheet" type="text/css" href="bower_components/bootstrap/dist/css/bootstrap.min.css"><link rel="stylesheet" type="text/css" href="default/assets/icon/themify-icons/themify-icons.css"><link rel="stylesheet" type="text/css" href="default/assets/icon/icofont/css/icofont.css"><link rel="stylesheet" type="text/css" href="default/assets/pages/flag-icon/flag-icon.min.css"><link rel="stylesheet" type="text/css" href="default/assets/css/style.css"><link rel="stylesheet" type="text/css" href="default/assets/css/color/color-1.css" id="color" /><link rel="stylesheet" type="text/css" href="default/assets/css/linearicons.css"><link rel="stylesheet" type="text/css" href="default/assets/css/simple-line-icons.css"><link rel="stylesheet" type="text/css" href="default/assets/css/ionicons.css"><link rel="stylesheet" type="text/css" href="default/assets/css/jquery.mCustomScrollbar.css">';

        // Load HTML to Dompdf
        $dompdf->loadHtml($html);

        // (Optional) Setup the paper size and orientation 'portrait' or 'portrait'
        $dompdf->setPaper('A4', 'portrait');

        // Render the HTML as PDF
        $dompdf->render();

        // Output the generated PDF to Browser (force download)
        $dompdf->stream("mypdf.pdf", [
            "Attachment" => true
        ]);
        */


    }

    /**
     * @param RendezvousRepository $rep
     * @param Request $r
     * @return Response
     * @Route("/test",name="test")
     */
    public function rechercheb(RendezvousRepository $rep,Request $r)
    {
        $u=$r->get('user');
        $c=$r->get('centre');
        $rep3=$this->getDoctrine()->getRepository(Centre::class);
        $centres=$rep3->findAll();
        $rep2=$this->getDoctrine()->getRepository(Utilisateur::class);
        $users=$rep2->findAll();

        $rdvs=$rep->searchback($c,$u,$r->get('d'));
        return $this->render('rendezvous/afficherb.html.twig'
            ,['rdvs'=>$rdvs,'centres'=>$centres,'users'=>$users]
        );

    }


    /**
     * @param $id
     * @param RendezvousRepository $rep
     * @param MailerInterface $mailer
     * @return \Symfony\Component\HttpFoundation\RedirectResponse
     * @throws \Symfony\Component\Mailer\Exception\TransportExceptionInterface
     * @Route("/mailrdv/{id}", name="mailrdv")
     */
    public function mailrdv($id,RendezvousRepository $rep,MailerInterface $mailer)
    {
        $em=$this->getDoctrine()->getManager();
        $r=$rep->find($id);

        $email = (new Email())
            ->from('amirakarchoud111@gmail.com')
            ->to($r->getIdUtilisateur()->getEmail())
            ->subject('Rappel du Rendez-vous')
            ->text('Detail du rendez-vous')
            ->html('<p>Date :'.$r->getDate()->format('Y-d-m').
                '<br>Temps:'.$r->getTemps()->format('H:i').
                '<br>Centre:'.$r->getIdCentre()->getNom().
                '<br>Adresse:'.$r->getIdCentre()->getLieu().
                '</p>');

        $mailer->send($email);
        return $this->redirectToRoute('afficherRdvB');
    }



}
