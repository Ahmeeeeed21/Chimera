<?php

namespace App\Controller;

use App\Entity\Centre;
use App\Entity\Service;
use App\Form\CentreServiceType;
use App\Form\CentreType;
use App\Form\ServiceType;
use App\Repository\CentreRepository;
use phpDocumentor\Reflection\Type;
use Gedmo\Sluggable\Util\Urlizer;
use phpDocumentor\Reflection\Types\Array_;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Serializer\Normalizer\NormalizerInterface;
use Knp\Component\Pager\PaginatorInterface;


class CentreController extends AbstractController
{
    /**
     * @Route("/centre", name="centre")
     */
    public function index(): Response
    {

        return $this->render('centre/test.html.twig', [
            'controller_name' => 'CentreController',
        ]);
    }



    /**
     * @return Response
     * @Route("/afficheCentre", name="centreb")
     */
    public function afficher()
    {
        $rep=$this->getDoctrine()->getRepository(Centre::class);
        $centres=$rep->findAll();

        return $this->render('centre/affiche.html.twig'
            ,['centres'=>$centres]
        );
    }


    /**
     * @return Response
     * @Route("/afficherCentre", name="centref")
     */
    public function afficherF(PaginatorInterface $paginator,Request $request)
    {
        $em=$this->getDoctrine()->getManager();
        $rep=$this->getDoctrine()->getRepository(Centre::class);
        //$centres=$rep->findAll();

        $dql   = "SELECT c FROM App\Entity\Centre c";
        $query = $em->createQuery($dql);

        $pagination = $paginator->paginate(
            $query, /* query NOT result */
            $request->query->getInt('page', 1), /*page number*/
            6 /*limit per page*/
        );


        return $this->render('centre/afficherF.html.twig'
            ,['centres'=>$pagination]
        );
    }


    /**
     * @param $id
     * @return \Symfony\Component\HttpFoundation\RedirectResponse
     * @Route("/supp/{id}" , name="supprimer")
     */
    public function supprimer($id)
    {
        $rep=$this->getDoctrine()->getRepository(Centre::class);
        $em=$this->getDoctrine()->getManager();
        $c=$rep->find($id);
        $em->remove($c);
        $em->flush();
        return $this->redirectToRoute('centreb');

    }


    /**
     * @param $id
     * @return Response
     * @Route("/detail/{id}", name="detail")
     */
    public function selectbyid($id)
    {
        $rep=$this->getDoctrine()->getRepository(Centre::class);
        $c=$rep->find($id);
        return $this->render('centre/detail.html.twig'
            ,['centre'=>$c]
        );
    }

    /**
     * @param $id
     * @return Response
     * @Route("/detailfront/{id}", name="detailcentref")
     */
    public function selectbyidfront($id)
    {
        $rep=$this->getDoctrine()->getRepository(Centre::class);
        $c=$rep->find($id);
        return $this->render('centre/detailfront.html.twig'
            ,['centre'=>$c]
        );
    }


    /**
     * @param Request $request
     * @return Response
     * @Route("/ajouterCentre",name="ajouterc")
     */
    public function ajouter(Request $request)
    {
        $centre= new Centre();
        $form=$this->createForm(CentreType::class,$centre);
        $form->add('Ajouter',SubmitType::class,['attr'=>['class'=>'btn btn-primary m-b-0']]);
        $form->handleRequest($request);

        if($form->isSubmitted() && $form->isValid())
        {  //image
            $uploadedFile = $form['image']->getData();
            $destination = $this->getParameter('kernel.project_dir').'/public/images/centre';
            $originalFilename = pathinfo($uploadedFile->getClientOriginalName(), PATHINFO_FILENAME);
            $newFilename = Urlizer::urlize($originalFilename).uniqid().'.'.$uploadedFile->guessExtension();
            $uploadedFile->move(
                $destination,
                $newFilename
            );

                $centre->setImage($newFilename);


            //ajout
            $em=$this->getDoctrine()->getManager();
            $em->persist($centre);
            $em->flush();
            return $this->redirectToRoute('centreb');
        }

        return $this->render('centre/ajouter.html.twig',
            ['form'=>$form->createView()]
        );
    }

    /**
     * @param $id
     * @param Request $request
     * @return \Symfony\Component\HttpFoundation\RedirectResponse|Response
     * @Route("/modifierCentre/{id}" ,name="modifierc")
     */
    public function modifier($id,Request $request)
    {
        $rep=$this->getDoctrine()->getRepository(Centre::class);
        $centre= $rep->find($id);
        $form=$this->createForm(CentreType::class,$centre);
        $form->add('Modifier',SubmitType::class,['attr'=>['class'=>'btn btn-primary m-b-0']]);
        $form->handleRequest($request);

        if($form->isSubmitted() && $form->isValid())
        {
            //image
            $uploadedFile = $form['image']->getData();
            $destination = $this->getParameter('kernel.project_dir').'/public/images/centre';
            $originalFilename = pathinfo($uploadedFile->getClientOriginalName(), PATHINFO_FILENAME);
            $newFilename = Urlizer::urlize($originalFilename).uniqid().'.'.$uploadedFile->guessExtension();
            $uploadedFile->move(
                $destination,
                $newFilename
            );

            $centre->setImage($newFilename);

            $em=$this->getDoctrine()->getManager();
            $em->flush();
            return $this->redirectToRoute('centreb');
        }

        return $this->render('centre/modifier.html.twig',
            ['form'=>$form->createView()]
        );
    }


    /**
     * @param Request $request
     * @param $id
     * @return \Symfony\Component\HttpFoundation\RedirectResponse|Response|null
     * @Route("/serviceCentre/{id}",name="ajoutercs")
     */
    public function ajouterservC(Request $request,$id)
    {
        //$service= new Service();
        $rep=$this->getDoctrine()->getRepository(Centre::class);
        $rep2=$this->getDoctrine()->getRepository(Service::class);
        $form=$this->createForm(CentreServiceType::class);
        $form->add('Ajouter',SubmitType::class,['attr'=>['class'=>'btn btn-primary m-b-0']]);
        $form->handleRequest($request);

        $c=$rep->find($id);
        if($form->isSubmitted() && $form->isValid())
        {
         $s=$rep2->find($form->getData()['idService']->getId());
         $c->addIdService($s);
        // $s->addIdCentre($c);
         //var_dump($s->getNom());
            //var_dump($c->getNom());
           //var_dump($s->getIdCentre());
            $em=$this->getDoctrine()->getManager();
            $em->persist($c);
            $em->flush();
            return $this->redirectToRoute('detail',['id'=>$c->getId()]);
        }

        return $this->render('centre/ajouterserv.html.twig',
            ['form'=>$form->createView(),'c'=>$c]
        );
    }


    /**
     * @param CentreRepository $rep
     * @return Response
     * @Route("/Recherchercf",name="recherchecentref")
     */
    public function rechercherCentre(CentreRepository $rep,Request $r,PaginatorInterface $paginator,Request $request)
    {
        $type=$r->get('type');
        $t=\DateTime::createFromFormat('H:i:s',$r->get('t1').':00');

        $query=$rep->search($type,$t);

        $centres = $paginator->paginate(
            $query, /* query NOT result */
            $request->query->getInt('page', 1), /*page number*/
            6 /*limit per page*/
        );


        return $this->render('centre/afficherF.html.twig'
            ,['centres'=>$centres]
        );

    }

    /**
     * @param CentreRepository $rep
     * @param Request $r
     * @param NormalizerInterface $Normalizer
     * @return Response
     * @throws \Symfony\Component\Serializer\Exception\ExceptionInterface
     * @Route("/rechercheNomAddCentre",name="recherchercentreb")
     */
    public function rechercherCentreB(CentreRepository $rep,Request $r,NormalizerInterface $Normalizer)
    {
        $x=$r->get('searchValue');

        $centres=$rep->searchnomadd($x);
        $jsonContent=$Normalizer->normalize($centres,'json',['groups'=>'centres:read']);
        $retour=json_encode($jsonContent);
      return new Response($retour);

    }


    /**
     * @param CentreRepository $rep
     * @return Response
     * @Route("/StatCentre" ,name="statCentre")
     */
    public function statCentre(CentreRepository $rep)
    {
        $r = $rep->statRdvByCentre();
        $r2 = $rep->statRdvByDate();
        //$r3=$rep->statServiceByCentre();
        //var_dump($r);
        $cc=$rep->statClientFidele();
        $ms=$rep->statMService();
        $rdvd=$rep->statRdv();
        //var_dump($c);
        $centres = $rep->findAll();
        $r3 = [];
        $i = 0;

            foreach ($centres as $c) {
                if($i<10 and $c->getIdService()->count()>0) {
                    $r3[] = ['nom' => $c->getNom(), 'val' => $c->getIdService()->count()];
                    $i++;
                }

            }


        return $this->render('centre/stat.html.twig',['s1'=>$r,'s2'=>$r2,'s3'=>$r3,'client'=>$cc,'ms'=>$ms,'rdv'=>$rdvd]);
    }







}
