<?php

namespace App\Repository;

use App\Entity\Centre;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @method Centre|null find($id, $lockMode = null, $lockVersion = null)
 * @method Centre|null findOneBy(array $criteria, array $orderBy = null)
 * @method Centre[]    findAll()
 * @method Centre[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class CentreRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Centre::class);
    }

    // /**
    //  * @return Centre[] Returns an array of Centre objects
    //  */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('c')
            ->andWhere('c.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('c.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */

    /*
    public function findOneBySomeField($value): ?Centre
    {
        return $this->createQueryBuilder('c')
            ->andWhere('c.exampleField = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    */


    public function search($type,$ouv)
    {

      $q= $this->createQueryBuilder('c')
            ->where('1 = :t')
          ->setParameter('t',1);
          if($ouv)
          {
              $q->andWhere($q->expr()->between(':ouv', 'c.hDeb', 'c.hFin'))
           ->setParameter('ouv',$ouv);
          }

        if($type)
        {$q->andWhere('c.type = :type')
            ->setParameter('type',$type);}
          return  $q->getQuery()
                    ;

    }

    public function searchnomadd($n)
    {
        return $this->createQueryBuilder('c')
            ->where('c.nom LIKE :n')
            ->orWhere('c.lieu LIKE :n')
            ->setParameter('n','%'.$n.'%')
            ->getQuery()
            ->getResult()
        ;
    }

    public function statRdvByCentre()
    {
        $em=$this->getEntityManager();
        $q=$em->createQuery(
            'select r as rdv, count(r.idCentre) as total from App\Entity\Rendezvous r
            group by r.idCentre'
        )->setMaxResults(10);
        return $q->getResult();
    }


    public function statRdvByDate()
    {
        $em=$this->getEntityManager();
        $q=$em->createQuery(
            'select r as rdv, count(r.date) as total from App\Entity\Rendezvous r
            group by r.date'
        )->setMaxResults(10)
        ;
        return $q->getResult();
    }

    public function statServiceByCentre()
    {
      // $em=$this->getEntityManager();
       // $q=$em->createQuery('select c as centre, count(s.id) as total from App\Entity\Centre c inner join App\Entity\Centre.idService s on s.id=c.idService.id group by s.id');
      /* $qb = $this->createQueryBuilder('cent');
        $result = $qb
            ->select('p')
            ->from('App\Entity\Centre', 'p')
            ->join('App\Entity\Service', 'u', 'WITH', 'u.id = p.idService.id')
            ->getQuery()
            ->getResult();

        return $result;*/
        //return $q->getResult();

        /*return $this->createQueryBuilder('c')
            ->innerJoin('c.idService', 's', 'WITH', 's.id = :superCategoryName')
            ->getQuery()
            ->getResult();

        $em = $this->getEntityManager();
        $qb = $this->createQueryBuilder('k')
            ->from('App\Entity\Centre','a')
            ->select('1')
            ->from('a.centre_service','sc')
            ->innerJoin('App\Entity\Centre','c','WITH','c.id= sc.id_centre')
            ->innerJoin('App\Entity\Service','s','WITH','s.id= sc.id_service')


        ;

        return $qb->getQuery()->getResult();*/

    }


    public function statClientFidele()
    {
        $em=$this->getEntityManager();
        $q=$em->createQuery(
            'select r as rdv, count(r.idUtilisateur) as total from App\Entity\Rendezvous r
            group by r.idUtilisateur order by total desc '
        )->setMaxResults(1);
        return $q->getResult();
    }


    public function statMService()
    {
        $em=$this->getEntityManager();
        $q=$em->createQuery(
            'select r as rdv, count(r.idService) as total from App\Entity\Rendezvous r
            group by r.idService order by total desc '
        )->setMaxResults(1);
        return $q->getResult();
    }

    public function statRdv()
    {
        $em=$this->getEntityManager();
        $q=$em->createQuery(
            'select r as rdv from App\Entity\Rendezvous r
            where r.date = CURRENT_DATE() '
        )->setMaxResults(1);
        return $q->getResult();
    }


}
