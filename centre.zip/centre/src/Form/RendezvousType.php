<?php

namespace App\Form;

use App\Entity\Centre;
use App\Entity\Rendezvous;
use App\Entity\Service;
use App\Entity\Utilisateur;
use Doctrine\DBAL\Types\DateType;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\TimeType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Context\ExecutionContextInterface;
use Symfony\Component\Validator\Constraints;


class RendezvousType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('date',\Symfony\Component\Form\Extension\Core\Type\DateType::class,['attr'=>['class'=>'form-control js-datepicker'], 'widget' => 'single_text'])
            ->add('temps',TimeType::class,['attr'=>['class'=>'form-control'],'widget'=>'single_text',
                'constraints'=>[new Constraints\Callback(function ($object,ExecutionContextInterface $context, $payload) {
                    $c=$context->getRoot()->getData()->getIdCentre();


                    if ($c->getHDeb()>$object || $c->getHFin()<$object) {
                        $context->buildViolation("Centre fermé! N.B: heure d'ouverture du centre : ".$c->getNom()." est: ".$c->getHDeb()->format('H:i')." et de fermeture: ".$c->getHFin()->format('H:i'))
                            ->atPath('temps')
                            ->addViolation();
                    }
                })]
                ])
            ->add('idCentre',EntityType::class,['class'=>Centre::class,'choice_label'=>'nom','attr'=>['class'=>'form-control']])
           // ->add('idUtilisateur',EntityType::class,['class'=>Utilisateur::class,'choice_label'=>'nom','attr'=>['class'=>'form-control']])
            ->add('idService',EntityType::class,['class'=>Service::class,'choice_label'=>'nom','attr'=>['class'=>'form-control']])
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Rendezvous::class,
        ]);
    }
}
