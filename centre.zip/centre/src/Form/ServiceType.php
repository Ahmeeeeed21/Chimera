<?php

namespace App\Form;

use App\Entity\Service;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;

class ServiceType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('nom',Type\TextType::class,['attr'=>['placeholder'=>'saisir le nom','class'=>'form-control']])
            ->add('description',Type\TextareaType::class,['attr'=>['placeholder'=>'saisir une description','class'=>'form-control']])
            ->add('type',ChoiceType::class, [
        'choices'  => [
            'Yoga' => 'yoga',
            'seance meditation' => 'seance meditation',
            'massage' => 'massage',
            'autre' => 'autre',
        ],
        'attr'=>['class'=>'form-control']
    ])
           // ->add('idCentre')
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Service::class,
        ]);
    }
}
