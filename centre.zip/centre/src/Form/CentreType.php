<?php

namespace App\Form;

use App\Entity\Centre;
use Doctrine\DBAL\Types\TextType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\FileType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type;
use Symfony\Component\Validator\Constraints\Time;
use Symfony\Component\Form\Extension\Core\Type\TimeType;
use Symfony\Component\Form\FormTypeInterface\DateTime;
use Symfony\Component\Validator\Constraints;
use Symfony\Component\Validator\Context\ExecutionContextInterface;

class CentreType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('nom',Type\TextType::class,['attr'=>['placeholder'=>'saisir le nom','class'=>'form-control']])
            ->add('lieu',Type\TextType::class,['attr'=>['placeholder'=>'adresse du centre','class'=>'form-control']])
            ->add('description',Type\TextareaType::class,['attr'=>['placeholder'=>'saisir une description','class'=>'form-control']])
            ->add('image',FileType::class,array('data_class' => null,'mapped'=>false))
            ->add('type', ChoiceType::class, [
                'choices'  => [
                    'Spa' => 'spa',
                    'centre de remise en forme' => 'centre de remise en forme',
                    'salle de sport' => 'salle de sport',
                ],
                'attr'=>['class'=>'form-control']
            ])
            ->add('hDeb', TimeType::class,['attr'=>['class'=>'form-control'],'widget'=>'single_text'])
            ->add('hFin',TimeType::class,['attr'=>['class'=>'form-control'],'widget'=>'single_text',
            'constraints'=>[new Constraints\Callback(function ($object,ExecutionContextInterface $context, $payload) {
                $start = $context->getRoot()->getData()->getHDeb();

                $stop = $object;

                if ($start > $stop) {
                    $context->buildViolation("L'heure d'ouverture doit être avant l'heure de fermeture!")
                        ->atPath('hFin')
                        ->addViolation();
                }
            })]
            ])
            //->add('idService')
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Centre::class,
        ]);
    }
}
